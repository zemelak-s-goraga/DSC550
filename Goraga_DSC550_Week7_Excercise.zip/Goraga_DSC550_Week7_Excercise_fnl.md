# Data Mining (DSC550-T301_2245_1)

Assignement Week 7;

Author: Zemelak Goraga;

Date: 04/27/2024


```python
# check current working directory
import os
print(os.getcwd())
```

    C:\Users\MariaStella\DSC550\wk7
    

# Activity 1: PCA and Variance Threshold in a Linear Regression:



```python
# Task 1: Import required libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import VarianceThreshold
import os
import warnings
warnings.filterwarnings('ignore')
```


```python
# Task 2: Import the Housing Dataset as a DataFrame

import os
import pandas as pd

# Change the current working directory to where the CSV file is located
os.chdir(r'C:\Users\MariaStella\DSC550\wk7')

# Now you can load the file directly by its name
df1 = pd.read_csv('train.csv')

# Check the first few rows to confirm it's loaded correctly
print(df1.head())

```

       Id  MSSubClass MSZoning  LotFrontage  LotArea Street Alley LotShape  \
    0   1          60       RL         65.0     8450   Pave   NaN      Reg   
    1   2          20       RL         80.0     9600   Pave   NaN      Reg   
    2   3          60       RL         68.0    11250   Pave   NaN      IR1   
    3   4          70       RL         60.0     9550   Pave   NaN      IR1   
    4   5          60       RL         84.0    14260   Pave   NaN      IR1   
    
      LandContour Utilities  ... PoolArea PoolQC Fence MiscFeature MiscVal MoSold  \
    0         Lvl    AllPub  ...        0    NaN   NaN         NaN       0      2   
    1         Lvl    AllPub  ...        0    NaN   NaN         NaN       0      5   
    2         Lvl    AllPub  ...        0    NaN   NaN         NaN       0      9   
    3         Lvl    AllPub  ...        0    NaN   NaN         NaN       0      2   
    4         Lvl    AllPub  ...        0    NaN   NaN         NaN       0     12   
    
      YrSold  SaleType  SaleCondition  SalePrice  
    0   2008        WD         Normal     208500  
    1   2007        WD         Normal     181500  
    2   2008        WD         Normal     223500  
    3   2006        WD        Abnorml     140000  
    4   2008        WD         Normal     250000  
    
    [5 rows x 81 columns]
    


```python

```


```python
# Task 3: Drop "Id" column and columns with more than 40% missing values
threshold = len(df1) * 0.6
df1 = df1.drop(columns=['Id'])
df1 = df1.dropna(thresh=threshold, axis=1)

df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>LotConfig</th>
      <th>LandSlope</th>
      <th>...</th>
      <th>EnclosedPorch</th>
      <th>3SsnPorch</th>
      <th>ScreenPorch</th>
      <th>PoolArea</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
      <th>SalePrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>60</td>
      <td>RL</td>
      <td>65.0</td>
      <td>8450</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>208500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20</td>
      <td>RL</td>
      <td>80.0</td>
      <td>9600</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>FR2</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>2007</td>
      <td>WD</td>
      <td>Normal</td>
      <td>181500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60</td>
      <td>RL</td>
      <td>68.0</td>
      <td>11250</td>
      <td>Pave</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>223500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>70</td>
      <td>RL</td>
      <td>60.0</td>
      <td>9550</td>
      <td>Pave</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Corner</td>
      <td>Gtl</td>
      <td>...</td>
      <td>272</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2006</td>
      <td>WD</td>
      <td>Abnorml</td>
      <td>140000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>60</td>
      <td>RL</td>
      <td>84.0</td>
      <td>14260</td>
      <td>Pave</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>FR2</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>250000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 75 columns</p>
</div>




```python
df1.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>LotConfig</th>
      <th>LandSlope</th>
      <th>...</th>
      <th>EnclosedPorch</th>
      <th>3SsnPorch</th>
      <th>ScreenPorch</th>
      <th>PoolArea</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
      <th>SalePrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1455</th>
      <td>60</td>
      <td>RL</td>
      <td>62.0</td>
      <td>7917</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
      <td>2007</td>
      <td>WD</td>
      <td>Normal</td>
      <td>175000</td>
    </tr>
    <tr>
      <th>1456</th>
      <td>20</td>
      <td>RL</td>
      <td>85.0</td>
      <td>13175</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
      <td>210000</td>
    </tr>
    <tr>
      <th>1457</th>
      <td>70</td>
      <td>RL</td>
      <td>66.0</td>
      <td>9042</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2500</td>
      <td>5</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
      <td>266500</td>
    </tr>
    <tr>
      <th>1458</th>
      <td>20</td>
      <td>RL</td>
      <td>68.0</td>
      <td>9717</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>112</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
      <td>142125</td>
    </tr>
    <tr>
      <th>1459</th>
      <td>20</td>
      <td>RL</td>
      <td>75.0</td>
      <td>9937</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>147500</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 75 columns</p>
</div>




```python
# Task 4 & 5: Fill missing numerical data with the median and categorical data with mode
numerical_cols = df1.select_dtypes(include=['number']).columns
categorical_cols = df1.select_dtypes(include=['object']).columns
df1[numerical_cols] = df1[numerical_cols].fillna(df1[numerical_cols].median())
df1[categorical_cols] = df1[categorical_cols].fillna(df1[categorical_cols].mode().iloc[0])

df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>LotConfig</th>
      <th>LandSlope</th>
      <th>...</th>
      <th>EnclosedPorch</th>
      <th>3SsnPorch</th>
      <th>ScreenPorch</th>
      <th>PoolArea</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
      <th>SalePrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>60</td>
      <td>RL</td>
      <td>65.0</td>
      <td>8450</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>208500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20</td>
      <td>RL</td>
      <td>80.0</td>
      <td>9600</td>
      <td>Pave</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>FR2</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>2007</td>
      <td>WD</td>
      <td>Normal</td>
      <td>181500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60</td>
      <td>RL</td>
      <td>68.0</td>
      <td>11250</td>
      <td>Pave</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>223500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>70</td>
      <td>RL</td>
      <td>60.0</td>
      <td>9550</td>
      <td>Pave</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Corner</td>
      <td>Gtl</td>
      <td>...</td>
      <td>272</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2006</td>
      <td>WD</td>
      <td>Abnorml</td>
      <td>140000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>60</td>
      <td>RL</td>
      <td>84.0</td>
      <td>14260</td>
      <td>Pave</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>FR2</td>
      <td>Gtl</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>12</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>250000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 75 columns</p>
</div>




```python

```


```python
# Task 6: Convert categorical columns to dummy variables
df1 = pd.get_dummies(df1, drop_first=True)

df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSSubClass</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>OverallQual</th>
      <th>OverallCond</th>
      <th>YearBuilt</th>
      <th>YearRemodAdd</th>
      <th>MasVnrArea</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinSF2</th>
      <th>...</th>
      <th>SaleType_ConLI</th>
      <th>SaleType_ConLw</th>
      <th>SaleType_New</th>
      <th>SaleType_Oth</th>
      <th>SaleType_WD</th>
      <th>SaleCondition_AdjLand</th>
      <th>SaleCondition_Alloca</th>
      <th>SaleCondition_Family</th>
      <th>SaleCondition_Normal</th>
      <th>SaleCondition_Partial</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>60</td>
      <td>65.0</td>
      <td>8450</td>
      <td>7</td>
      <td>5</td>
      <td>2003</td>
      <td>2003</td>
      <td>196.0</td>
      <td>706</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20</td>
      <td>80.0</td>
      <td>9600</td>
      <td>6</td>
      <td>8</td>
      <td>1976</td>
      <td>1976</td>
      <td>0.0</td>
      <td>978</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60</td>
      <td>68.0</td>
      <td>11250</td>
      <td>7</td>
      <td>5</td>
      <td>2001</td>
      <td>2002</td>
      <td>162.0</td>
      <td>486</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>70</td>
      <td>60.0</td>
      <td>9550</td>
      <td>7</td>
      <td>5</td>
      <td>1915</td>
      <td>1970</td>
      <td>0.0</td>
      <td>216</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>60</td>
      <td>84.0</td>
      <td>14260</td>
      <td>8</td>
      <td>5</td>
      <td>2000</td>
      <td>2000</td>
      <td>350.0</td>
      <td>655</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 233 columns</p>
</div>




```python
# Task 7: Split the data into training and test sets
X = df1.drop('SalePrice', axis=1)
y = df1['SalePrice']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSSubClass</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>OverallQual</th>
      <th>OverallCond</th>
      <th>YearBuilt</th>
      <th>YearRemodAdd</th>
      <th>MasVnrArea</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinSF2</th>
      <th>...</th>
      <th>SaleType_ConLI</th>
      <th>SaleType_ConLw</th>
      <th>SaleType_New</th>
      <th>SaleType_Oth</th>
      <th>SaleType_WD</th>
      <th>SaleCondition_AdjLand</th>
      <th>SaleCondition_Alloca</th>
      <th>SaleCondition_Family</th>
      <th>SaleCondition_Normal</th>
      <th>SaleCondition_Partial</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>254</th>
      <td>20</td>
      <td>70.0</td>
      <td>8400</td>
      <td>5</td>
      <td>6</td>
      <td>1957</td>
      <td>1957</td>
      <td>0.0</td>
      <td>922</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1066</th>
      <td>60</td>
      <td>59.0</td>
      <td>7837</td>
      <td>6</td>
      <td>7</td>
      <td>1993</td>
      <td>1994</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>638</th>
      <td>30</td>
      <td>67.0</td>
      <td>8777</td>
      <td>5</td>
      <td>7</td>
      <td>1910</td>
      <td>1950</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>799</th>
      <td>50</td>
      <td>60.0</td>
      <td>7200</td>
      <td>5</td>
      <td>7</td>
      <td>1937</td>
      <td>1950</td>
      <td>252.0</td>
      <td>569</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>380</th>
      <td>50</td>
      <td>50.0</td>
      <td>5000</td>
      <td>5</td>
      <td>6</td>
      <td>1924</td>
      <td>1950</td>
      <td>0.0</td>
      <td>218</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 232 columns</p>
</div>




```python
X_test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MSSubClass</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>OverallQual</th>
      <th>OverallCond</th>
      <th>YearBuilt</th>
      <th>YearRemodAdd</th>
      <th>MasVnrArea</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinSF2</th>
      <th>...</th>
      <th>SaleType_ConLI</th>
      <th>SaleType_ConLw</th>
      <th>SaleType_New</th>
      <th>SaleType_Oth</th>
      <th>SaleType_WD</th>
      <th>SaleCondition_AdjLand</th>
      <th>SaleCondition_Alloca</th>
      <th>SaleCondition_Family</th>
      <th>SaleCondition_Normal</th>
      <th>SaleCondition_Partial</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>892</th>
      <td>20</td>
      <td>70.0</td>
      <td>8414</td>
      <td>6</td>
      <td>8</td>
      <td>1963</td>
      <td>2003</td>
      <td>0.0</td>
      <td>663</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1105</th>
      <td>60</td>
      <td>98.0</td>
      <td>12256</td>
      <td>8</td>
      <td>5</td>
      <td>1994</td>
      <td>1995</td>
      <td>362.0</td>
      <td>1032</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>413</th>
      <td>30</td>
      <td>56.0</td>
      <td>8960</td>
      <td>5</td>
      <td>6</td>
      <td>1927</td>
      <td>1950</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>522</th>
      <td>50</td>
      <td>50.0</td>
      <td>5000</td>
      <td>6</td>
      <td>7</td>
      <td>1947</td>
      <td>1950</td>
      <td>0.0</td>
      <td>399</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1036</th>
      <td>20</td>
      <td>89.0</td>
      <td>12898</td>
      <td>9</td>
      <td>5</td>
      <td>2007</td>
      <td>2008</td>
      <td>70.0</td>
      <td>1022</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 232 columns</p>
</div>




```python
y_train.head()
```




    254     145000
    1066    178000
    638      85000
    799     175000
    380     127000
    Name: SalePrice, dtype: int64




```python
y_test.head()
```




    892     154500
    1105    325000
    413     115000
    522     159000
    1036    315500
    Name: SalePrice, dtype: int64




```python

```


```python
# Task 8: Linear Regression Model
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
```


```python
# Task 9: Calculate R2-value and RMSE
r2 = r2_score(y_test, y_pred)
rmse = mean_squared_error(y_test, y_pred, squared=False)
print(f"R2-value: {r2}")
print(f"RMSE: {rmse}")
```

    R2-value: 0.6483838610509296
    RMSE: 51932.7496426966
    


```python
# Task 10. Run a linear regression and report the R2-value and RMSE on the test set.

from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

# Assume X_train and X_test are already prepared and split appropriately
# Assume y_train and y_test are also ready from previous steps

# Initialize the linear regression model
model = LinearRegression()

# Fit the model on the training data
model.fit(X_train, y_train)

# Make predictions on the test data
y_pred = model.predict(X_test)

# Calculate the R2 value
r2 = r2_score(y_test, y_pred)

# Calculate the RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the results
print(f"R2-value: {r2:.2f}")
print(f"RMSE: ${rmse:,.2f}")
```

    R2-value: 0.65
    RMSE: $51,932.75
    


```python
# Task 11: Fit and transform the training features with PCA to retain 90% of variance
pca = PCA(n_components=0.9)
X_train_pca = pca.fit_transform(X_train)

```


```python
# Task 12: Number of features in the PCA-transformed matrix
num_features_pca = X_train_pca.shape[1]
print(f"Number of features after PCA: {num_features_pca}")

```

    Number of features after PCA: 1
    


```python
# Task 13: Transform but DO NOT fit the test features with the same PCA
X_test_pca = pca.transform(X_test)
```


```python
# Task 14: Repeat Linear Regression with PCA-transformed data
model_pca = LinearRegression()
model_pca.fit(X_train_pca, y_train)
y_pred_pca = model_pca.predict(X_test_pca)

# Calculate and print R2-value and RMSE for PCA model
r2_pca = r2_score(y_test, y_pred_pca)
rmse_pca = mean_squared_error(y_test, y_pred_pca, squared=False)
print(f"PCA Model - R2-value: {r2_pca}, RMSE: {rmse_pca}")
```

    PCA Model - R2-value: 0.06348978215929679, RMSE: 84754.58021370923
    


```python
# Task 15: Apply Min-Max Scaler to original training features
scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
```


```python
# Task 16 & 17: Find scaled features in training set that have variance above 0.1
variances = np.var(X_train_scaled, axis=0)
high_variance_features = variances > 0.1
X_train_high_variance = X_train_scaled[:, high_variance_features]

high_variance_features
```




    array([False, False, False, False, False, False,  True, False, False,
           False, False, False, False, False, False, False, False, False,
           False, False, False, False, False, False, False, False, False,
           False, False, False, False, False, False, False, False,  True,
           False, False,  True,  True, False, False, False,  True, False,
           False, False, False, False, False, False,  True, False, False,
           False, False, False, False, False, False, False, False, False,
           False, False,  True, False, False, False, False, False, False,
           False, False, False, False, False, False, False,  True, False,
           False, False, False, False, False, False, False, False, False,
           False, False, False, False, False, False, False, False,  True,
           False, False,  True, False, False,  True, False,  True, False,
           False, False, False, False, False, False, False, False, False,
           False, False, False, False,  True, False,  True, False, False,
           False,  True,  True, False, False, False, False, False, False,
            True, False,  True, False, False, False, False,  True,  True,
           False,  True,  True, False, False,  True,  True, False, False,
           False,  True,  True,  True, False, False, False, False,  True,
            True, False, False, False, False, False,  True, False,  True,
           False, False,  True, False, False, False, False, False, False,
           False, False, False, False, False,  True, False,  True, False,
           False, False, False, False, False,  True,  True, False, False,
           False, False, False, False,  True, False, False, False,  True,
            True,  True, False, False, False, False, False, False, False,
           False, False, False, False, False, False, False, False, False,
           False,  True, False, False, False,  True, False])




```python
# Task 18: Transform but DO NOT fit the test features with the same steps applied in steps 11 and 12
X_test_high_variance = scaler.transform(X_test)[:, high_variance_features]
```


```python
# Task 19: Repeat Linear Regression with high variance data
model_high_variance = LinearRegression()
model_high_variance.fit(X_train_high_variance, y_train)
y_pred_high_variance = model_high_variance.predict(X_test_high_variance)
```


```python
# Task 20: Calculate and print R2-value and RMSE for High Variance Features Model
r2_high_variance = r2_score(y_test, y_pred_high_variance)
rmse_high_variance = mean_squared_error(y_test, y_pred_high_variance, squared=False)
print(f"High Variance Features Model - R2-value: {r2_high_variance}, RMSE: {rmse_high_variance}")

```

    High Variance Features Model - R2-value: 0.6542858267265509, RMSE: 51495.05299983065
    


```python

```

# Discussion Activity 1:

Predicting house prices with precision is an intricate challenge influenced by a diverse array of variables. Optimizing feature preprocessing is critical for enhancing model performance. This study assesses the effectiveness of PCA and Variance Thresholding as feature transformation methods in refining a linear regression model tasked with predicting house prices.

The dataset comprises numerous features that potentially introduce noise or redundancy. Implementing effective dimensionality reduction and feature selection techniques can streamline the model, enhancing accuracy and computational efficiency in predictions. This research seeks to ascertain which method offers significant improvements for linear regression models in predicting house prices.

The initial data preplues with medians (for numerical features) and modes (for categorical features). Post categorical variable conversion into dummy variables, the dataset was divided into training and testing subsets.

Three distinct linear regression models underwent training and evaluation:
Baseline Model: Employed all preprocessed features.
PCA Model: Retained 90% of the variance through PCA.
High Variance Features Model: Implemented Min-Max scaling and Variance Thresholding to select features with variaration involved removing features with excessive missing values and substituting remaining missing vaance above 0.1.

Model performances were assessed using the R2-value and RMSE (Root Mean Squared Error).

Baseline Model: Achieved an R2-value of 0.65 and an RMSE of $51,932.75.
PCA Model: Noted a substantial drop in performance with an R2-value of 0.063 and an RMSE of $84,754.58, indicating that the model severely lost predictive accuracy.
High Variance Features Model: Demonstrated slight improvement with an R2-value of 0.654 and an RMSE of $51,495.05.

The findings suggest that while PCA significantly reduces dimensionality, it may discard essential predictive features, resulting in considerable performance degradation. On the other hand, the High Variance Features Model, which retains only the most informative attributes post-scaling, shows a marginal improvement in predictive accuracy over the baseline model.



```python

```

# Activity 2: Categorical Feature Selection:


```python
# Task 1: Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.feature_selection import SelectKBest, chi2
import matplotlib.pyplot as plt
```


```python
# Task 2: Import the Housing Dataset as a DataFrame

import os
import pandas as pd

# Change the current working directory to where the CSV file is located
os.chdir(r'C:\Users\MariaStella\DSC550\wk7')

# Now you can load the file directly by its name
df2 = pd.read_csv('mushrooms.csv')

# Check the first few rows to confirm it's loaded correctly
print(df2.head())

```

      class cap-shape cap-surface cap-color bruises odor gill-attachment  \
    0     p         x           s         n       t    p               f   
    1     e         x           s         y       t    a               f   
    2     e         b           s         w       t    l               f   
    3     p         x           y         w       t    p               f   
    4     e         x           s         g       f    n               f   
    
      gill-spacing gill-size gill-color  ... stalk-surface-below-ring  \
    0            c         n          k  ...                        s   
    1            c         b          k  ...                        s   
    2            c         b          n  ...                        s   
    3            c         n          n  ...                        s   
    4            w         b          k  ...                        s   
    
      stalk-color-above-ring stalk-color-below-ring veil-type veil-color  \
    0                      w                      w         p          w   
    1                      w                      w         p          w   
    2                      w                      w         p          w   
    3                      w                      w         p          w   
    4                      w                      w         p          w   
    
      ring-number ring-type spore-print-color population habitat  
    0           o         p                 k          s       u  
    1           o         p                 n          n       g  
    2           o         p                 n          n       m  
    3           o         p                 k          s       u  
    4           o         e                 n          a       g  
    
    [5 rows x 23 columns]
    


```python

```


```python
# Task 3: Inspect the Dataset

print(df2.info())  # Display a concise summary of the DataFrame
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 8124 entries, 0 to 8123
    Data columns (total 23 columns):
     #   Column                    Non-Null Count  Dtype 
    ---  ------                    --------------  ----- 
     0   class                     8124 non-null   object
     1   cap-shape                 8124 non-null   object
     2   cap-surface               8124 non-null   object
     3   cap-color                 8124 non-null   object
     4   bruises                   8124 non-null   object
     5   odor                      8124 non-null   object
     6   gill-attachment           8124 non-null   object
     7   gill-spacing              8124 non-null   object
     8   gill-size                 8124 non-null   object
     9   gill-color                8124 non-null   object
     10  stalk-shape               8124 non-null   object
     11  stalk-root                8124 non-null   object
     12  stalk-surface-above-ring  8124 non-null   object
     13  stalk-surface-below-ring  8124 non-null   object
     14  stalk-color-above-ring    8124 non-null   object
     15  stalk-color-below-ring    8124 non-null   object
     16  veil-type                 8124 non-null   object
     17  veil-color                8124 non-null   object
     18  ring-number               8124 non-null   object
     19  ring-type                 8124 non-null   object
     20  spore-print-color         8124 non-null   object
     21  population                8124 non-null   object
     22  habitat                   8124 non-null   object
    dtypes: object(23)
    memory usage: 1.4+ MB
    None
    


```python
# Task 4: Convert Categorical Features to Dummy Variables

df2_encoded = pd.get_dummies(df2, drop_first=True)

```


```python
# Task 5: Split the Data into a Training and Test Set

from sklearn.model_selection import train_test_split

# Define features and target
X = df2_encoded.drop('class_p', axis=1)
y = df2_encoded['class_p']

# Splitting the data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
```


```python
# Task 6: Fit a Decision Tree Classifier

from sklearn.tree import DecisionTreeClassifier

# Initialize and train the decision tree classifier
clf = DecisionTreeClassifier(random_state=42)
clf.fit(X_train, y_train)

```




<style>#sk-container-id-1 {color: black;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>DecisionTreeClassifier(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">DecisionTreeClassifier</label><div class="sk-toggleable__content"><pre>DecisionTreeClassifier(random_state=42)</pre></div></div></div></div></div>




```python
# Task 7: Report the Accuracy and Create a Confusion Matrix

from sklearn.metrics import accuracy_score, confusion_matrix

# Make predictions
y_pred = clf.predict(X_test)

# Calculate accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# Generate confusion matrix
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

```

    Accuracy: 1.0
    Confusion Matrix:
     [[1257    0]
     [   0 1181]]
    


```python
# Task 8: Create a Visualization of the Decision Tree

import matplotlib.pyplot as plt
from sklearn.tree import plot_tree

# Plot the decision tree
plt.figure(figsize=(20,10))
plot_tree(clf, filled=True, feature_names=X.columns.tolist())  # Convert to list
plt.show()

```


    
![png](output_40_0.png)
    



```python

```


```python
# Task 9: Use a χ2-Statistic Selector to Pick the Five Best Features

from sklearn.feature_selection import SelectKBest, chi2

# Apply SelectKBest class to extract top 5 features
selector = SelectKBest(score_func=chi2, k=5)
X_new = selector.fit_transform(X, y)

# Get the names of the selected features
selected_features = X.columns[selector.get_support()]
print("Selected features:", selected_features)
```

    Selected features: Index(['odor_f', 'odor_n', 'gill-size_n', 'stalk-surface-above-ring_k',
           'stalk-surface-below-ring_k'],
          dtype='object')
    


```python
# Task 10 & 11: Repeat with Selected Features

X_train_sel, X_test_sel, y_train, y_test = train_test_split(X_new, y, test_size=0.3, random_state=42)
clf.fit(X_train_sel, y_train)
y_pred_sel = clf.predict(X_test_sel)
print("Accuracy with selected features:", accuracy_score(y_test, y_pred_sel))

```

    Accuracy with selected features: 0.9741591468416735
    


```python

```


# Discussion Activity 2:

Mushrooms present a significant challenge in terms of edibility, with some species being highly toxic and others safe for consumption. Traditional methods of determining mushroom edibility, which typically rely on expert knowledge, are not scalable or accessible to all. Machine learning offers a robust alternative, automating edibility predictions based on observable characteristics. This study focuses on the application of a decision tree classifier to automate and improve the accuracy of these predictions.

The primary challenge in mushroom classification is the accurate and reliable distinction between edible and poisonous categories based on observable categorical features. The stakes of accurate classification are high, given the potential health implications of incorrect identifications.

The mushroom dataset, sourced from the UCI Machine Learning Repository, comprises categorical descriptions of mushroom features. I encoded these categories into dummy variables to facilitate computational analysis. A decision tree classifier was trained on 70% of the dataset, with its performance subsequently evaluated on the remaining 30%. Feature importance was assessed using the χ2-statistic to select the top five most predictive features.

The decision tree classifier achieved an accuracy of 100% on the test dataset, indicating perfect classification. The confusion matrix confirmed the absence of false negatives and false positives. A subset of features selected using the χ2-statistic, including 'odor_f', 'odor_n', 'gill-size_n', 'stalk-surface-above-ring_k', and 'stalk-surface-below-ring_k', was used to retrain the classifier. This reduced feature set achieved an accuracy of 97.42%, slightly lower than the full model but still highly effective.

The high accuracy of the initial model indicates the decision tree's effectiveness in handling categorical data and confirms its suitability for classifying mushroom edibility. The key features identified align with known mycological indicators, such as odor, which is a critical factor in mushroom identification. The slight decrease in accuracy with fewer features underscores the complexity of mushroom classification and suggests that while select features are highly informative, other features also contribute to the model's predictive power.



```python

```


# Short Report on Both Activities:


Title: Enhancing Predictive Models Using Feature Transformation and Selection Techniques

Summary:
This comprehensive report synthesizes findings from two separate studies exploring the impact of feature transformation and feature selection on the predictive accuracy of models in two distinct domains: real estate pricing and mushroom edibility. Through detailed evaluation of different methods including Principal Component Analysis (PCA), Variance Thresholding, and χ2-statistic based feature selection, this report offers insights into how best to optimize machine learning models for increased accuracy and practical applicability in diverse fields.

Introduction:
Predictive modeling plays a crucial role in various sectors by facilitating informed decision-making based on historical data. However, the effectiveness of these models significantly depends on the preprocessing techniques used to handle features. This report examines the outcomes of two different approaches—feature transformation in house price prediction and feature selection in mushroom edibility classification—to determine optimal strategies for improving model accuracy.

Statement of the Problem:
In predictive modeling, the presence of redundant or irrelevant features can lead to decreased model accuracy and efficiency. In the realm of real estate, numerous features may introduce noise, while in biological classifications such as mushroom edibility, the high stakes of correct classification necessitate extremely reliable models. This report explores methodologies to refine feature handling and enhance the predictive performance of models across different applications.

Methodology:
The studies reviewed employed varied methodologies appropriate to their specific data types and objectives:

Real Estate Prediction
Data Preparation: Removal of features with high missing values, imputation of remaining missing values, and conversion of categorical variables.
Model Training: Comparison of a Baseline Model, PCA Model, and a High Variance Features Model using linear regression.
Mushroom Edibility Classification
Data Preparation: Encoding of categorical descriptions into dummy variables.
Model Training: Application of a decision tree classifier with a subsequent evaluation of feature importance via the χ2-statistic.

Results:
House Price Prediction:
Baseline Model achieved moderate accuracy.
PCA Model showed significant performance drop.
High Variance Features Model slightly outperformed the Baseline Model.

Mushroom Edibility:
Initial model achieved 100% accuracy.
Reduced feature set model demonstrated high accuracy but slightly lower than the full model.

Discussion:
The studies indicate that while PCA can overly simplify a model resulting in lost critical information, techniques like Variance Thresholding preserve essential features enhancing model performance. In biological classifications, the use of a targeted feature selection approach, even with a reduced set, maintains high accuracy, suggesting that careful selection based on domain-specific knowledge is crucial.

Conclusions:
The analysis across both domains supports the use of nuanced feature selection and transformation techniques over broad-stroke approaches like PCA for predictive modeling. Employing targeted feature selection or transformation specific to the dataset's nature and the predictive task at hand can significantly improve a model's accuracy and reliability.

The Way Forward:
Future research should focus on hybrid approaches combining the strengths of different feature handling techniques. Experimentation with more complex models and inclusion of additional types of data could further refine predictions. Developing practical applications, such as real-time prediction tools for end-users in the real estate and public health sectors, could be a fruitful direction, enhancing the utility and accessibility of predictive models.

This integrated approach to examining feature handling across different modeling scenarios provides valuable insights, paving the way for enhanced predictive accuracy and model efficiency in various applications.


```python

```
